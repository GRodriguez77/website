const express = require('express');
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const qs = require('querystring');
const nodemailer = require('nodemailer');
const uuidv1 = require('uuid/v1');
const mimeTypes = {
  '.html': 'text/html',
  '.htm': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.ico': 'image/x-icon',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.json': 'application/json',
  '.mp3': 'audio/mpeg',
  '.m4a': 'audio/mpeg'
};
var port = process.env.PORT || 8080;
var bodyParser = require('body-parser');
var mongodb = require('mongodb');
const MongoClient = require('mongodb').MongoClient;
var uri = 'mongodb+srv://grodriguez:<SK1uyKHXqByIawPN>@cluster0-sljtl.mongodb.net/test?retryWrites=true&w=majority';
var dbConnect = mongodb.MongoClient.connect(uri);

var app = express();
app.use(bodyParser.urlencoded({extended: false}));

app.use(express.static('public'));

// mongodb code
app.post('/feedback-post', function(req, res) {
  dbConnect.then(function(db) {
    db.collection('feedbacks').insertOne(req.body);
    console.log("Collection creation successful");
  });
  res.send('Thank you for your feedback.');
  sendEmail(parsed['email'],ts);
  dbConnect.close();
});

console.log("listening...");

http.createServer(app).listen(port);
/*
app.post('/views/contactMe.html', function(req, res){
  var body = '';
  req.on('data', function(chunk) {
    body += chunk.toString();
  });
  req.on('end', function(){
    var ts = Date.now();
    var parsed = qs.parse(body);
    fs.appendFile('dataFile.txt', convertToString(parsed, ts), function(error){
      if (error) {
        console.log('Could not add to dataFile.txt error: ', error);
        throw error;
      }
      console.log('Writing to dataFile.txt successful');
    });
    sendEmail(parsed['email'], ts);
    res.writeHead(301, {'Content-Type': 'text/plain', Location: '/'});
    res.end();
  });
});
*/

app.get('*', function(req, res) {
  var pathname = url.parse(req.url).pathname;

  pathname = (pathname === '/' || pathname === '') ? '/index.html': pathname;

  var ext = path.extname(pathname);

  fs.readFile(__dirname + pathname, function(err, data) {
    if (err) {
      if (ext) {
        res.writeHead(404, {'Content-Type': mimeTypes[ext]});
        console.log("error line 62", err);
      }
      else {
        res.writeHead(404, {'Content-Type': 'text/html'});
        console.log("error line 66", err);
      }
      return res.end("404 Not Found");
    }
    if (ext) {
      res.writeHead(200, {'Content-Type': mimeTypes[ext]});
    }
    else {
      res.writeHead(200, {'Content-Type': 'text/html'});
    }
    res.write(data);
    return res.end();
  });
});

function convertToString(dirty, ts) {
  dirty.id = uuidv1();
  dirty.created_at = Date();
  dirty.reference_id = ts;
  return JSON.stringify(dirty);
}

function sendEmail(email, reference) {
  var transporter = nodemailer.createTransport({
    service: 'gmail',
    host: 'smtp.gmail.com',
    port: 465 || 587,
    auth: {
      user: 'RODRIGUEZGILDAWEBSITE',
      pass: 'WebsiteEmailPassword350'
    }
  });
  var mailOptions = {
    from: "rodriguezgildawebsite@gmail.com",
    to: email,
    subject: "Thank You",
    text: "Thank you for your feedback!\nYour reference number is "+ reference +"."
  };

  transporter.verify(function(error,success){
    if (error) {
      console.log("error ", error);
    }
    else {
      console.log('Server is ready to take our messages');
    }
  });
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    }
    else {
      console.log("Email sent: ", + info.response);
    }
  });
}
