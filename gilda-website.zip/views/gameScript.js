/* Gilda Rodriguez
// code for game
*/
function start() {
	document.getElementById("inst").innerHTML = "Please click on 5 arbitrary spots within this box to see a shape";
	document.getElementById("show").style.display = "block";
}
function shapeGame(event) { 
	var canvas = document.getElementById("canvas");
	if (canvas.getContext){
		var ctx = canvas.getContext("2d"); // the canvas object's context
		var x = event.clientX;
		var y = event.clientY;
		// SHAPE = ["rectangle","square","circle","line","triangle"] <-- 5 shapes
		var COLOR = ["red","orange","yellow","green","cyan","blue","purple",]; // 7 colors
		var chooseShape;
		var chooseColor;
		var height;
		var width;
		var radius;
		
		x -= canvas.offsetLeft;
		y -= canvas.offsetTop;
		chooseShape = Math.floor(Math.random()*5);
		chooseColor1 = Math.floor(Math.random()*7);
		chooseColor2 = Math.floor(Math.random()*7);
	
		/** Shapes */
		// rectangle
		if (chooseShape === 0) {
			height = Math.random()*200;
			width = Math.random()*200;
			while (height == width){
				height = Math.random()*200;
				width = Math.random()*200;
			}
			ctx.beginPath();
			ctx.strokeStyle = COLOR[chooseColor2];
			ctx.strokeRect(x,y,width,height);
			
			ctx.fillStyle = COLOR[chooseColor1];
			ctx.fillRect(x,y,width,height);
		}
		// Square
		else if (chooseShape == 1) { 
			width = Math.random()*200;
			ctx.beginPath();
			ctx.strokeStyle = COLOR[chooseColor2];
			ctx.strokeRect(x,y,width,width);
			
			ctx.fillStyle = COLOR[chooseColor1];
			ctx.fillRect(x,y,width,width);
		}
		// Circle
		else if (chooseShape == 2) { 
			radius = Math.random()*50;
			ctx.beginPath();
			ctx.arc(x,y,radius,0,2*Math.PI);
			ctx.strokeStyle = COLOR[chooseColor2];
			ctx.stroke();
			
			ctx.fillStyle = COLOR[chooseColor1];
			ctx.fill();
		}
		// Line
		else if (chooseShape == 3) {
			var dis = Math.random()*200;
			var sign = Math.random(); // sign<0.5 = negative, sign>=0.5 = positive
			ctx.beginPath();
			ctx.moveTo(x,y);
			if(sign<0.5) {
				ctx.lineTo(x-dis,y-dis);
			}
			else{
				ctx.lineTo(x+dis,y+dis);
			}
			ctx.strokeStyle = COLOR[chooseColor2];
			ctx.stroke();
		}
		// Triangle
		else if (chooseShape == 4) {
			var b = Math.random()*200;
			var c = Math.random()*200;
			
			ctx.beginPath();
			ctx.moveTo(x,y);
			var nY = y + b;
			ctx.lineTo(x,nY);
			ctx.lineTo(nY,x+c);
			ctx.closePath();
			ctx.strokeStyle = COLOR[chooseColor2];
			ctx.stroke();
			
			ctx.fillStyle = COLOR[chooseColor1];
			ctx.fill();
		}
	}
}
